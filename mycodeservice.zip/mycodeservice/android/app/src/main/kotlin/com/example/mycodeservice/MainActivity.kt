package com.example.mycodeservice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
