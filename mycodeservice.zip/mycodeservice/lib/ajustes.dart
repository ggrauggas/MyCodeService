import 'package:flutter/material.dart';

import 'navigation.dart';

class Ajustes extends StatefulWidget {
  const Ajustes({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<Ajustes> createState() => _MyAjustesPageState();
}

class _MyAjustesPageState extends State<Ajustes> {


  @override
  void initState() {
    super.initState();
    navigation = Navigation(context);
  }

  late Navigation navigation;

  void _navigateToCantidades() {
    Navigator.pop(context);
  }


  void _navigateToSubirDatos() {}

  void _navigateToAjustesFTP() {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: TextStyle(fontSize: 30, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Color(0xFF3304F8),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFF7E57C2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 1.8],
            tileMode: TileMode.clamp,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: 50),
              SizedBox(
                width: 300,
                height: 70,
                child: ElevatedButton(
                  onPressed: navigation.navigateToNombre,
                  child: Text(
                    'CONFIGURAR NOMBRE',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ), backgroundColor: Color(0xFF3304F8),
                  ),
                ),
              ),
              SizedBox(height: 30),
              SizedBox(
                width: 300,
                height: 70,
                child: ElevatedButton(
                  onPressed: navigation.navigateToTotal,
                  child: Text(
                    'MOSTRAR TOTAL',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ), backgroundColor: Color(0xFF3304F8),
                  ),
                ),
              ),
              SizedBox(height: 30),
              SizedBox(
                width: 300,
                height: 70,
                child: ElevatedButton(
                  onPressed: _navigateToSubirDatos,
                  child: Text(
                    'ELIMINAR DATOS',
                    style: TextStyle(fontSize: 20, color: Colors.red),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ), backgroundColor: Color(0xFF3304F8),
                  ),
                ),
              ),
              SizedBox(height: 30),
              SizedBox(
                width: 300,
                height: 70,
                child: ElevatedButton(
                  onPressed: _navigateToAjustesFTP,
                  child: Text(
                    'AJUSTES FTP',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ), backgroundColor: Color(0xFF3304F8),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
