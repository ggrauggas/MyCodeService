import 'dart:convert';
import 'package:flutter/material.dart';
import 'buscador.dart';
import 'database/DatabaseProvider.dart';
import 'navigation.dart';

class Inventario extends StatefulWidget {
  const Inventario({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<Inventario> createState() => _MyContenidoPageState();
}

class _MyContenidoPageState extends State<Inventario> {
  late Navigation navigation;
  late Future<List<Map<String, dynamic>>> _inventariosFuture;
  final TextEditingController _codigoController = TextEditingController();
  final TextEditingController _codigoController2 = TextEditingController();

  @override
  void initState() {
    super.initState();
    navigation = Navigation(context);
    _initializeDatabase();
  }

  Future<void> _initializeDatabase() async {
    final databaseProvider = DatabaseProvider();
    await databaseProvider.initialize();
    setState(() {
      _inventariosFuture = databaseProvider.mostrarInventarios();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: const TextStyle(fontSize: 20, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF3304F8),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFF7E57C2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 1.8],
            tileMode: TileMode.clamp,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20), // Espacio entre el EditText y la lista

            // Aquí puedes agregar tus EditText
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10), // Espaciado interno para el TextField
                      decoration: BoxDecoration(
                        color: Colors.transparent, // Fondo transparente
                        border: Border.all(color: Colors.black), // Bordes negros
                      ),
                      child: TextField(
                        controller: _codigoController,
                        style: TextStyle(color: Colors.black), // Color del texto
                        cursorColor: Colors.lightBlue,
                        onSubmitted: (value) {
                          _agregarCodigoALaBaseDeDatos(value.trim(), _codigoController2.text.trim()); // Agregar nombre del segundo TextField
                          _codigoController.clear();
                          _codigoController2.clear();

                        },
                        decoration: InputDecoration(
                          hintText: 'Introduce el código...', // Hint para el TextField
                          hintStyle: TextStyle(color: Colors.grey), // Color del hint
                          border: InputBorder.none, // Eliminar el borde del TextField
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      _navigateToBuscador(context);
                    },
                  ),
                ],
              ),
            ),

            // Espacio entre el EditText y el segundo TextField
            const SizedBox(height: 20),

            // Segundo TextField que no se puede editar sin usar la lupa
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.grey,
                  border: Border.all(color: Colors.black),
                ),
                child: TextField(
                  controller: _codigoController2,
                  readOnly: true, // No editable
                  style: TextStyle(color: Colors.black),
                  cursorColor: Colors.lightBlue,
                  decoration: InputDecoration(
                    hintText: '-',
                    hintStyle: TextStyle(color: Colors.black),
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),

            Expanded(
              child: FutureBuilder<List<Map<String, dynamic>>>(
                future: _inventariosFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  } else if (snapshot.hasError) {
                    return Center(
                      child: Text('Error al cargar los datos: ${snapshot.error}'),
                    );
                  } else {
                    final inventarios = snapshot.data!;
                    return ListView.builder(
                      itemCount: inventarios.length,
                      itemBuilder: (context, index) {
                        final inventario = inventarios[index];
                        return ListTile(
                          title: Text(inventario['codigo']),
                          onTap: () => _onItemSelected(context, inventario), // Agregar manejo de selección de artículo
                          subtitle: Text(
                              'Cantidad: ${inventario['cantidad']} Nombre: ${inventario['nombre']}'),
                        );

                      },
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }


  void _agregarCodigoALaBaseDeDatos(String codigo, String nombre) async {
    final databaseProvider = DatabaseProvider();
    await databaseProvider.initialize();
    await databaseProvider.addInventario(codigo, "Empresa", 1, nombre); // Usar el nombre pasado como argumento
    setState(() {
      _inventariosFuture = databaseProvider.mostrarInventarios();
    });
  }

  void _navigateToBuscador(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ArticulosWindow(onArticuloSelected: _onArticuloSelected)),
    );
  }


  // Agregar función para manejar la selección de artículo
  void _onArticuloSelected(Articulo articulo) {
    // Actualizar el texto del controlador del código con el código del artículo seleccionado
    _codigoController.text = articulo.codigo.toString();
    _codigoController2.text = articulo.descripcion.toString();
    // Otras acciones según sea necesario al seleccionar un artículo
  }

  void _onItemSelected(BuildContext context, Map<String, dynamic> inventario) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Eliminar artículo'),
        content: Text('¿Que desea hacer con el artículo con codigo ${inventario['codigo']} de la lista?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Cerrar el diálogo
            },
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              _eliminarArticulo(inventario['id']);
              Navigator.pop(context); // Cerrar el diálogo
            },
            child: Text('Eliminar'),
          ),
        ],
      ),
    );
  }

  void _eliminarArticulo(int id) async {
    final databaseProvider = DatabaseProvider();
    await databaseProvider.initialize();
    await databaseProvider.eliminarInventarioPorId(id);
    setState(() {
      _inventariosFuture = databaseProvider.mostrarInventarios();
    });
  }

}
