import 'package:flutter/material.dart';
import 'package:mycodeservice/RegistroPage.dart';


class LoadingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 20),
            Text('Inicializando base de datos...'),
          ],
        ),
      ),
    );
  }
}

class AppInitializer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 2), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => RegistroPage(title: "REGISTRO")));
    });

    return LoadingScreen(); // Muestra la pantalla de carga mientras tanto
  }
}

