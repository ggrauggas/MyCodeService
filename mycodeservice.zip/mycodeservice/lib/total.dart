import 'package:flutter/material.dart';


class Total extends StatefulWidget {
  const Total({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<Total> createState() => _MyContenidoPageState();
}

class _MyContenidoPageState extends State<Total> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: TextStyle(fontSize: 30, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Color(0xFF3304F8),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFF7E57C2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 1.8],
            tileMode: TileMode.clamp,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: 50),

            ],
          ),
        ),
      ),
    );
  }
}
