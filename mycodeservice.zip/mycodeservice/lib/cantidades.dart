import 'package:flutter/material.dart';
import 'buscador.dart';
import 'database/DatabaseProvider.dart';
import 'navigation.dart';

class Cantidad extends StatefulWidget {
  const Cantidad({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<Cantidad> createState() => _MyContenidoPageState();
}

class _MyContenidoPageState extends State<Cantidad> {
  late Navigation navigation;
  late Future<List<Map<String, dynamic>>> _cantidadFuture;
  final TextEditingController _codigoController = TextEditingController();
  final TextEditingController _codigoController2 = TextEditingController();
  final TextEditingController _codigoController3 = TextEditingController();
  final FocusNode _cantidadFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    navigation = Navigation(context);
    _initializeDatabase();
  }

  @override
  void dispose() {
    _codigoController.dispose();
    _codigoController2.dispose();
    _codigoController3.dispose();
    _cantidadFocusNode.dispose();
    super.dispose();
  }

  Future<void> _initializeDatabase() async {
    final databaseProvider = DatabaseProvider();
    await databaseProvider.initialize();
    setState(() {
      _cantidadFuture = databaseProvider.mostrarCantidad();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: const TextStyle(fontSize: 20, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF3304F8),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFF7E57C2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 1.8],
            tileMode: TileMode.clamp,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20), // Espacio entre el EditText y la lista

            // Aquí puedes agregar tus EditText
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10), // Espaciado interno para el TextField
                      decoration: BoxDecoration(
                        color: Colors.transparent, // Fondo transparente
                        border: Border.all(color: Colors.black), // Bordes negros
                      ),
                      child: TextField(
                        controller: _codigoController,
                        style: TextStyle(color: Colors.black), // Color del texto
                        cursorColor: Colors.lightBlue,
                        onSubmitted: _onCodigoSubmitted,
                        decoration: InputDecoration(
                          hintText: 'Introduce el código...', // Hint para el TextField
                          hintStyle: TextStyle(color: Colors.grey), // Color del hint
                          border: InputBorder.none, // Eliminar el borde del TextField
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      _navigateToBuscador(context);
                    },
                  ),
                ],
              ),
            ),

            // Espacio entre el EditText y el segundo TextField
            const SizedBox(height: 20),

            // Segundo TextField que no se puede editar sin usar la lupa
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  border: Border.all(color: Colors.black),
                ),
                child: TextField(
                  keyboardType: TextInputType.number,
                  controller: _codigoController3,
                  focusNode: _cantidadFocusNode,
                  onSubmitted: _onCantidadSubmitted,
                  style: TextStyle(color: Colors.black),
                  cursorColor: Colors.lightBlue,
                  decoration: InputDecoration(
                    hintText: 'Introduce la cantidad...',
                    hintStyle: TextStyle(color: Colors.grey), // Color del hint
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.grey,
                  border: Border.all(color: Colors.black),
                ),
                child: TextField(
                  controller: _codigoController2,
                  readOnly: true, // No editable
                  style: TextStyle(color: Colors.black),
                  cursorColor: Colors.lightBlue,
                  decoration: InputDecoration(
                    hintText: '-',
                    hintStyle: TextStyle(color: Colors.black),
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
            Expanded(
              child: FutureBuilder<List<Map<String, dynamic>>>(
                future: _cantidadFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  } else if (snapshot.hasError) {
                    return Center(
                      child: Text('Error al cargar los datos: ${snapshot.error}'),
                    );
                  } else {
                    final inventarios = snapshot.data!;
                    return ListView.builder(
                      itemCount: inventarios.length,
                      itemBuilder: (context, index) {
                        final cantidad = inventarios[index];
                        return ListTile(
                          title: Text(cantidad['codigo']),
                          onTap: () => _onItemSelected(context, cantidad),
                          subtitle: Text(
                              'Cantidad: ${cantidad['cantidad']} Nombre: ${cantidad['nombre']}'),
                        );
                      },
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _agregarCodigoALaBaseDeDatos(String codigo, String nombre, int cantidad) async {
    final databaseProvider = DatabaseProvider();
    await databaseProvider.initialize();
    await databaseProvider.addCantidad(codigo, "Empresa", cantidad, nombre); // Usar el nombre pasado como argumento
    setState(() {
      _cantidadFuture = databaseProvider.mostrarCantidad();
    });
  }

  void _navigateToBuscador(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ArticulosWindow(onArticuloSelected: _onArticuloSelected)),
    );
  }

  void _onCodigoSubmitted(String value) {
    FocusScope.of(context).requestFocus(_cantidadFocusNode); // Enfocar el campo de cantidad
  }

  void _onCantidadSubmitted(String value) {
    try {
      int tercerElemento = int.parse(value.trim());
      if(tercerElemento!=0){
        _agregarCodigoALaBaseDeDatos(_codigoController.text.trim(), _codigoController2.text.trim(), tercerElemento);

        _codigoController.clear();
        _codigoController2.clear();
        _codigoController3.clear();
      }


    } catch (FormatException) {
      print('El tercer elemento no es un número entero válido.');
    }
  }

  void _onItemSelected(BuildContext context, Map<String, dynamic> cantidad) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Modificar cantidad'),
        content: Text('¿Qué desea hacer con el artículo con código ${cantidad['codigo']} de la lista?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Cerrar el diálogo
            },
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              _eliminarCantidad(cantidad['id']);
              Navigator.pop(context);
            },
            child: Text('Eliminar'),
          ),TextButton(
            onPressed: () {
              _eliminarCantidad(cantidad['id']);
              Navigator.pop(context);
            },
            child: Text('Modificar'),
          ),
        ],
      ),
    );
  }


  void _onArticuloSelected(Articulo articulo) {

    _codigoController.text = articulo.codigo.toString();
    _codigoController2.text = articulo.descripcion.toString();
    FocusScope.of(context).requestFocus(_cantidadFocusNode);
  }


  void _eliminarCantidad(int id) async {
    final databaseProvider = DatabaseProvider();
    await databaseProvider.initialize();
    await databaseProvider.eliminarCantidadPorId(id);
    setState(() {
      _cantidadFuture = databaseProvider.mostrarCantidad();
    });
  }
}
