import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseProvider extends ChangeNotifier {
  late Database _database;
  bool _initialized = false;

  bool get initialized => _initialized;

  Database get database => _database;

  DatabaseProvider() {
    _initDatabase();
  }

  Future<void> _initDatabase() async {
    _database = await openDatabase(
      join(await getDatabasesPath(), 'inventario.db'),
      onCreate: (db, version) {
        db.execute(
          "CREATE TABLE inventario(id INTEGER PRIMARY KEY AUTOINCREMENT, codigo TEXT, empresa TEXT, cantidad INTEGER, nombre TEXT)",
        );
        // Crear tabla cantidad
        db.execute(
          "CREATE TABLE cantidad(id INTEGER PRIMARY KEY AUTOINCREMENT, codigo TEXT, empresa TEXT, cantidad INTEGER, nombre TEXT)",
        );
      },
      version: 1,
    );
    _initialized = true;
    notifyListeners();
  }

  Future<void> initialize() async {
    if (!_initialized) {
      await _initDatabase();
    }
  }

  Future<void> eliminarInventarioPorId(int id) async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    await _database.delete(
      'inventario',
      where: 'id = ?',
      whereArgs: [id],
    );
    notifyListeners();
  }


  Future<void> eliminarCantidadPorId(int id) async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    await _database.delete(
      'cantidad',
      where: 'id = ?',
      whereArgs: [id],
    );
    notifyListeners();
  }


  Future<void> addInventario(String codigo, String empresa, int cantidad, String nombre) async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    await _database.insert(
      'inventario',
      {
        'codigo': codigo,
        'empresa': empresa,
        'cantidad':cantidad,
        'nombre': nombre,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    notifyListeners();
  }
  Future<void> addCantidad(String codigo, String empresa, int cantidad, String nombre) async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    await _database.insert(
      'cantidad',
      {
        'codigo': codigo,
        'empresa': empresa,
        'cantidad':cantidad,
        'nombre': nombre,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    notifyListeners();
  }

  Future<List<Map<String, dynamic>>> mostrarInventarios() async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    final List<Map<String, dynamic>> inventarios = await _database.query('inventario');
    return inventarios;
  }
  Future<List<Map<String, dynamic>>> mostrarCantidad() async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    final List<Map<String, dynamic>> cantidad = await _database.query('cantidad');
    return cantidad;
  }

  Future<void> borrarTodoElInventario() async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    await _database.delete('inventario');
    notifyListeners();
  }

  Future<void> borrarTodoCantidad() async {
    if (!_initialized) {
      throw Exception("La base de datos no ha sido inicializada.");
    }
    await _database.delete('cantidad');
    notifyListeners();
  }



}