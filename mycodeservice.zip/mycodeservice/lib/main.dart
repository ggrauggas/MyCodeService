import 'dart:io';

import 'package:flutter/material.dart';
import 'package:mycodeservice/RegistroPage.dart';
import 'package:provider/provider.dart';
import 'package:mycodeservice/database/DatabaseProvider.dart';
import 'LoadingSceen.dart';
import 'package:firebase_core/firebase_core.dart';

Future<void> main() async {
 WidgetsFlutterBinding.ensureInitialized();
 Platform.isAndroid ?   await Firebase.initializeApp(
   options: FirebaseOptions(
       apiKey: "AIzaSyDyGDFDeiKMp-x7PvlUMgW9DnMvKAjHcec",
       appId: "1:808493454507:android:51133669e59f43882213ee",
       messagingSenderId: "808493454507",
       projectId: "mycodeservice-516e1")


 ): await Firebase.initializeApp();
 runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => DatabaseProvider(),
      child: MaterialApp(
        title: 'My App',
        theme: ThemeData(),
        home: AppInitializer(),
      ),
    );
  }
}
class AppInitializer extends StatefulWidget {
  @override
  _AppInitializerState createState() => _AppInitializerState();
}

class _AppInitializerState extends State<AppInitializer> {
  late DatabaseProvider _databaseProvider;

  @override
  void initState() {
    super.initState();
    _initDatabase();
  }

  Future<void> _initDatabase() async {
    _databaseProvider = Provider.of<DatabaseProvider>(context, listen: false);
    await _databaseProvider.initialize();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (_databaseProvider.initialized) {
      return RegistroPage(title: "REGISTRO");
    } else {
      return LoadingScreen();
    }
  }
}
