import 'package:flutter/material.dart';
import 'database/DatabaseProvider.dart';
import 'navigation.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final databaseProvider = DatabaseProvider();
  late Navigation navigation;

  @override
  void initState() {
    super.initState();
    navigation = Navigation(context);
  }

  void navigateToCantidades() {
    navigation.navigateToCantidades();
  }

  void navigateToInventario() {}

  void navigateToSubirDatos() {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: TextStyle(fontSize: 30, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Color(0xFF3304F8),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFF7E57C2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 1.8],
            tileMode: TileMode.clamp,
          ),
        ),
        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(height: 100),
                  SizedBox(
                    width: 300,
                    height: 70,
                    child: ElevatedButton(
                      onPressed: navigation.navigateToCantidades,
                      child: Text(
                        'CANTIDADES',
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        backgroundColor: Color(0xFF3304F8),
                        padding: EdgeInsets.all(20),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  SizedBox(
                    width: 300,
                    height: 70,
                    child: ElevatedButton(
                      onPressed: navigation.navigateToInventario,
                      child: Text(
                        'INVENTARIO',
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        backgroundColor: Color(0xFF3304F8),
                        padding: EdgeInsets.all(20),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  SizedBox(
                    width: 300,
                    height: 70,
                    child: ElevatedButton(
                      onPressed: () {
                        databaseProvider.borrarTodoElInventario();
                        databaseProvider.borrarTodoCantidad();
                      },
                      child: Text(
                        'SUBIR DATOS',
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        backgroundColor: Color(0xFF1E0B89),
                        padding: EdgeInsets.all(20),
                      ),
                    ),
                  )

                ],
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Column(
                children: [
                  SizedBox(height: kToolbarHeight), // Para dejar espacio para el AppBar
                  Image.asset(
                    'imagenes/logo.png',
                    height: 150,
                    fit: BoxFit.contain,
                  ),
                ],
              ),
            ),

          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: navigation.navigateToAjustes,
        tooltip: 'Ajustes',
        backgroundColor: Colors.cyan,
        child: const Icon(Icons.settings_sharp),
      ),
    );
  }
}
