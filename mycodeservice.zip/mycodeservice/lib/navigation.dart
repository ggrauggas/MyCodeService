import 'package:flutter/material.dart';
import 'package:mycodeservice/home.dart';
import 'package:mycodeservice/total.dart';
import 'ajustes.dart';
import 'buscador.dart';
import 'cantidades.dart';
import 'inventario.dart';
import 'nombre.dart';

class Navigation {
 BuildContext context;

 Navigation(this.context);

 void navigateToAjustes() {
  Navigator.push(
   context,
   MaterialPageRoute(builder: (context) => Ajustes(title: "AJUSTES")),
  );
 }

 void navigateToNombre() {
  Navigator.push(
   context,
   MaterialPageRoute(builder: (context) => Nombre(title: "NOMBRE DE EMPRESA")),
  );
 }




 void navigateToMenu() {
  Navigator.push(
   context,
   MaterialPageRoute(builder: (context) => MyHomePage(title: "MENU")),
  );
 }

 void navigateToTotal() {
  Navigator.push(
   context,
   MaterialPageRoute(builder: (context) => Total(title: "TOTAL")),
  );
 }
 void navigateToCantidades() {
  Navigator.push(
   context,
   MaterialPageRoute(builder: (context) => Cantidad(title: "CANTIDADES")),
  );
 }

 void navigateToInventario() {
  Navigator.push(
   context,
   MaterialPageRoute(builder: (context) => Inventario(title: "INVENTARIO")),
  );
 }
}
